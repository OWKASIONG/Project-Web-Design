<!DOCTYPE html>
<html lang="zxx">
<head>
<?php
session_start();
?>
<?php
if(isset($_GET['action'])){
    $messages=simplexml_load_file('contact.xml');
    $name=$_GET['name'];
    $index=0;
    $i=0;
    foreach($messages->message as $message){
        if($message['name']==$name){
            $index = $i;
            break;
        }
        $i++;
    }
    unset($messages->message[$index]);
    file_put_contents('contact.xml',$users ->asXML());
	header('location:contactlist.php');
}
$messages = simplexml_load_file('contact.xml');
?>
    <meta charset="UTF-8">
    <meta name="description" content="Fashi Template">
    <meta name="keywords" content="Fashi, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Message-Bang Bang Bang</title>
    <link rel="icon"  sizes="40x10" type="image/png" href="img/head_logo.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/themify-icons.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
   <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container">
            <div class="inner-header">
                <div class="row">
                    <div class="col-lg-2 col-md-2">
                        <div class="logo">
                            <a href="./index1.html">
                                <img src="img/logo1.png" alt="">
                            </a>
                        </div>
                    </div>
					<div class="col-lg-7 col-lg-7">
                        <div class="advanced-search">
                            <button type="button" class="category-btn">All Categories</button>
                            <form action="shop.html" class="input-group">
                                <input type="text" placeholder="Search.." name="search">
                                <button type="search"><i class="ti-search"></i></button>
                            </form>
                        </div>
                    </div>
					<div class="col-lg-3 text-right col-md-3">
                        <ul class="nav-right">
                            <li class="heart-icon">
                                <a href="shop.html">
                                    <i class="icon_heart_alt"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="nav-item">
            <div class="container">
                <div class="nav-depart">
                    <div class="depart-btn">
                        <i class="ti-menu"></i>
                        <span>All Categories</span>
                        <ul class="depart-hover">
                            <li ><a href="Candy.html">Candy</a></li>
                            <li><a href="Chocalate.html">Chocalate</a></li>
                            <li><a href="Snack.html">Snack</a></li>
                            <li><a href="Wafer.html">Wafer</a></li>
                        </ul>
                    </div>
                </div>
                <nav class="nav-menu mobile-menu">
                    <ul>
                        <li><a href="./index1.html">Home</a></li>
                        <li><a href="./shop.html">Shop</a></li>
                        <li><a href="./contact.php">Contact</a></li>
						<li><a href="./shopping-cart.html">Checkout</a></li>
                        <li><a href="#">Pages</a>
                            <ul class="dropdown">
                                <li><a href="./register.php">Register</a></li>
                                <li><a href="./login.php">Login</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="index.html"><i class="fa fa-home"></i> Home</a>
						<a href="./listuser.php">Admin</a>
                        <span>Message</span>
                    
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section Begin -->
<div class="container" style="padding-top: 30px;padding-bottom:30px;">
<?php
echo'Number of message: '.count($messages);
echo'<br>List Message Information';?>
<table cellpadding="2" cellspacing="2" border="1">
<tr>
<td colspan="5"><span ><a href="listuser.php"><input type="button" value="Back" /></a></span></td>
</tr>
<tr>
<th>Name</th>
<th>Tel</th>
<th>Email</th>
<th>Message</th>
<th>Option</th>
</tr>
<?php foreach($messages->message as $message){?>
<tr>
<td><?php echo $message['name'];?></td>
<td><?php echo $message->tel;?></td>
<td><?php echo $message->email;?></td>
<td><?php echo $message->content;?></td>
<td><a href="?action=delete&id=<?php echo $message['name'];?>"onclick="return confirm('Are you sure ?')"><input type="submit" value="delete"></a></td>
</tr>
<?php }?>
</table>
</div>
           <!-- Partner Logo Section Begin -->
    <div class="partner-logo" style="padding-top: 30px;" >
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <a href="slideshow.html"><img src="img/logo-carousel/klogo.png" alt=""></a>
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <a href="slideshow.html"><img src="img/logo-carousel/milk.png" alt=""></a>
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <a href="slideshow.html"><img src="img/logo-carousel/Mameelogo.JPG" alt=""></a>
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <a href="slideshow.html"><img src="img/logo-carousel/mentoslogo.png" alt=""></a>
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <a href="slideshow.html"><img src="img/logo-carousel/sklogo2.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Partner Logo Section End -->

    <!-- Footer Section Begin -->
    <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="index1.html"><img src="img/footer-logo1.png" alt=""></a>
                        </div>
                        <ul>
                            <li>Address: 66, Jalan 1/12, Seksyen 1, 46000 Petaling Jaya, Selangor</li>
                            <li>Phone: 03-7782 7753</li>
                            <li>Email: bangbangban@gmail.com</li>
                        </ul>

                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1">
                    <div class="footer-widget">
                        <h5>Information</h5>
                        <ul>
                            <li><a href="about.html">About Us</a></li>
                            <li><a href="faq.html">Faq</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="footer-widget">
                        <h5>My Account</h5>
                        <ul>
                            <li><a href="register.php">Register</a></li>
                            <li><a href="shopping-cart.html">Shopping Cart</a></li>
                        </ul>
                    </div>
                </div>
				<div class="col-lg-4">
                    <div class="newslatter-item">
                        <h5>Join Our Newsletter Now</h5>
                        <p>Get E-mail updates about our latest shop and special offers.</p>
                        <form action="#" class="subscribe-form">
                            <input type="text" placeholder="Enter Your Mail">
                            <button type="button">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made by Ow Ka Siong, Wong Luo Fung and Chiew Chia Yu

<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </div>
                        <div class="payment-pic">
                            <img src="img/payment-method.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>