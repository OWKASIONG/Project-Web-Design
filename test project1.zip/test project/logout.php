<?php
   session_start();
   unset($_SESSION["id"]);
   unset($_SESSION["pass"]);

   echo 'You have Logout'; //pattern when lagging
   session_destroy();
   header('Refresh: 0.5; URL = login.php');
?>